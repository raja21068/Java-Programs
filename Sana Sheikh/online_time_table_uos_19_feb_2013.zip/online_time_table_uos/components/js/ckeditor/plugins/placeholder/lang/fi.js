﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('placeholder','fi',{placeholder:{title:'Paikkamerkin ominaisuudet',toolbar:'Luo paikkamerkki',text:'Paikkamerkin teksti',edit:'Muokkaa paikkamerkkiä',textMissing:'Paikkamerkin täytyy sisältää tekstiä'}});
