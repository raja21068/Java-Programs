package com.example.trainsearch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import android.widget.Toast;

public class DatabaseManager {


	    static Statement st;
	    static Connection con;
	    static {
	        
	        try {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://192.168.1.2:3306/train_reservation","c","");
//				Statement st = con.createStatement();
	        } catch (Exception ex) {
	        	ex.printStackTrace();
	        }
	    }
	    public static Object[] getTrains(){
	    	Vector v = new Vector();
	    	try{
	    	Statement st = con.createStatement();
	    	ResultSet rs = st.executeQuery("SELECT * FROM train");
	    	while(rs.next()){
	    		v.add(rs.getString("train_name"));
	    	}
	    	}
	    	catch(Exception ex){}
	    	return v.toArray();
	    }
	    public static Vector<String> getCities() throws SQLException{
//	    	Toast.makeText(MainActivity.session.getApplicationContext(), "query", Toast.LENGTH_LONG).show();
	        String query = "SELECT * FROM years";
//	    	Toast.makeText(MainActivity.session.getApplicationContext(), "statement", Toast.LENGTH_LONG).show();
	        st = con.createStatement();
//	    	Toast.makeText(MainActivity.session.getApplicationContext(), "statement ok", Toast.LENGTH_LONG).show();
//	        ResultSet rs = st.executeQuery(query);
	        Vector<String> v = new Vector<String>();
	  //      while(rs.next()){
	    //    	v.add(rs.getString("city_name"));
	      //  }
	        return v;
	    }
}
