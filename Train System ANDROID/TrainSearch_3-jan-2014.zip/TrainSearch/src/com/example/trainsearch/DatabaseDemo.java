package com.example.trainsearch;

public class DatabaseDemo {
	DatabaseDemo(){
//		Object[] trains = DatabaseManager.getTrains();
//		ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, trains);
//        train.setAdapter(adapter);
//		String[] array_spinner=new String[5];
//		try{
//			System.out.println(">>>> Class Loaded...<<<");
//			Class.forName("com.mysql.jdbc.Driver");
//			System.out.println(">>>> Connection Loaded...<<<");
//			Connection con = DriverManager.getConnection("jdbc:mysql://192.168.1.5:3306/train_reservation","saqib","RjPBpdyU7m4wavsP");
//			System.out.println(">>>> Statement Loaded...<<<");
//			Statement st = con.createStatement();
//			System.out.println(">>>> Query Loaded...<<<");
//			ResultSet rs = st.executeQuery("SELECT * FROM city");
		//	Vector v = new Vector()
//			while(rs.next()){
	//			String s = rs.getString("city_from");
//				v.add
//				System.out.println(s);
//				Toast.makeText(getApplicationContext(), ""+s, Toast.LENGTH_SHORT).show();
	//		}
//		}catch(Exception ex){
//			ex.printStackTrace();
//			Toast.makeText(getApplicationContext(), ""+ex, Toast.LENGTH_SHORT).show();
//		}
		
		
		
		//ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, array_spinner);
        //cityFrom.setAdapter(adapter);
//        Vector<String> v;
//		try{
			//Toast.makeText(getApplicationContext(), "hello", Toast.LENGTH_LONG).show();
			//v = DatabaseManager.getCities();
//			Toast.makeText(getApplicationContext(), "hello", Toast.LENGTH_LONG).show();
			//System.out.println("helo");
			//for(int i=0; i>v.size(); i++){
//				adapter.add(v.elementAt(i));
		//		adapter.notifyDataSetChanged();
				//System.out.println(v.elementAt(i));
			//}
//		}
//		catch(Exception ex){
//			Toast.makeText(getApplicationContext(), "Exception: "+ex.toString(), Toast.LENGTH_LONG).show();
//        	System.out.println(ex);
//			ex.printStackTrace();}

	}
}
